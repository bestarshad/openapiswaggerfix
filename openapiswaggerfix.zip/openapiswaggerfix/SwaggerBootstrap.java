import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;

import io.swagger.v3.core.converter.ModelConverters;
import io.swagger.v3.core.util.Json;


public class SwaggerBootstrap extends HttpServlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

	@Override
	public void init(ServletConfig config) throws ServletException {
       super.init(config);
       Json.mapper().registerModule(new JaxbAnnotationModule());
       //TypeNameResolver.std.setUseFqn(true);
       ModelConverters.getInstance().addConverter(new CustomConverter(Json.mapper()));
   }
	
	
}