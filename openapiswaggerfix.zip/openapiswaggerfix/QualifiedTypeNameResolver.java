import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import io.swagger.v3.core.jackson.TypeNameResolver;
import io.swagger.v3.core.util.AnnotationsUtils;
import io.swagger.v3.oas.annotations.media.Schema;


class QualifiedTypeNameResolver extends TypeNameResolver {

    @Override
    protected String nameForClass(Class<?> cls, Set<Options> options)
    {
      if (options.contains(Options.SKIP_API_MODEL)) {
        return cls.getName();
      }
      Schema mp = AnnotationsUtils.getSchemaDeclaredAnnotation(cls);
      
      String modelName = mp == null ? null : StringUtils.trimToNull(mp.name());
      return modelName == null ? cls.getName() : modelName;
    }
}